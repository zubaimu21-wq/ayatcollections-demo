/**
 * Header: mobile menu and search panel.
 */
(function () {
	'use strict';

	function setup() {
		var header = document.getElementById('site-header');
		if (!header) {
			return;
		}
		var menuBtn = header.querySelector('.menu-toggle');
		var nav = document.getElementById('primary-nav');
		var searchBtn = header.querySelector('.search-toggle');
		var search = document.getElementById('header-search');

		function closeMenu() {
			if (!menuBtn) { return; }
			menuBtn.setAttribute('aria-expanded', 'false');
			header.classList.remove('menu-open');
			document.body.classList.remove('no-scroll');
		}

		if (menuBtn && nav) {
			menuBtn.addEventListener('click', function () {
				var open = menuBtn.getAttribute('aria-expanded') === 'true';
				menuBtn.setAttribute('aria-expanded', open ? 'false' : 'true');
				header.classList.toggle('menu-open', !open);
				document.body.classList.toggle('no-scroll', !open);
				if (!open) {
					var first = nav.querySelector('a');
					if (first) { first.focus(); }
				}
			});
		}

		if (searchBtn && search) {
			searchBtn.addEventListener('click', function () {
				var open = searchBtn.getAttribute('aria-expanded') === 'true';
				searchBtn.setAttribute('aria-expanded', open ? 'false' : 'true');
				search.hidden = open;
				if (!open) {
					closeMenu();
					var input = search.querySelector('input[type="search"]');
					if (input) { input.focus(); }
				}
			});
		}

		document.addEventListener('keydown', function (e) {
			if (e.key !== 'Escape') { return; }
			if (header.classList.contains('menu-open')) {
				closeMenu();
				menuBtn.focus();
			}
			if (search && !search.hidden) {
				search.hidden = true;
				searchBtn.setAttribute('aria-expanded', 'false');
				searchBtn.focus();
			}
		});

		if (nav) {
			nav.addEventListener('click', function (e) { if (e.target.closest('a')) { closeMenu(); } });
		}
	}

	// Jewellery box pause/play (the box opens and closes on a loop) + gentle scroll reveal.
	function motion() {
		var still = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		var box = document.querySelector('[data-jbox]');
		var toggle = document.querySelector('[data-jbox-toggle]');
		if (box && toggle) {
			toggle.addEventListener('click', function () {
				var paused = box.classList.toggle('is-paused');
				toggle.setAttribute('aria-pressed', paused ? 'true' : 'false');
				toggle.querySelector('[data-label]').textContent = paused ? toggle.getAttribute('data-play') : toggle.getAttribute('data-pause');
				toggle.querySelector('[aria-hidden]').textContent = paused ? '▶' : '❚❚';
			});
		}
		var items = document.querySelectorAll('[data-reveal]');
		if (still || !('IntersectionObserver' in window) || !items.length) { return; }
		document.documentElement.classList.add('js-reveal');
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) {
				if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
			});
		}, { rootMargin: '0px 0px -8% 0px' });
		items.forEach(function (el) { io.observe(el); });
	}
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', motion);
	} else {
		motion();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', setup);
	} else {
		setup();
	}
})();

/* Homepage carousel: arrows, dots, autoplay (pauses on hover/focus or when hidden). */
(function () {
	var root = document.querySelector('[data-slider]');
	if (!root) return;
	var track = root.querySelector('[data-slider-track]');
	var slides = track.children;
	var dots = root.querySelectorAll('[data-slider-dots] button');
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var index = 0, timer = null, paused = false;
	function paint() {
		for (var k = 0; k < slides.length; k++) { slides[k].classList.toggle('is-active', k === index); }
		for (var d = 0; d < dots.length; d++) {
			if (d === index) dots[d].setAttribute('aria-current', 'true'); else dots[d].removeAttribute('aria-current');
		}
	}
	var moving = false;
	function go(i) {
		index = (i + slides.length) % slides.length;
		paint();
		moving = true;
		setTimeout(function () { moving = false; }, 700);
		track.scrollTo({ left: slides[index].offsetLeft, behavior: reduce ? 'instant' : 'smooth' });
	}
	function mark() {
		if (moving || !track.clientWidth) return;
		index = Math.round(track.scrollLeft / track.clientWidth);
		paint();
	}
	var t;
	track.addEventListener('scroll', function () { clearTimeout(t); t = setTimeout(mark, 60); }, { passive: true });
	root.querySelector('[data-slider-prev]').addEventListener('click', function () { go(index - 1); });
	root.querySelector('[data-slider-next]').addEventListener('click', function () { go(index + 1); });
	for (var d = 0; d < dots.length; d++) {
		dots[d].addEventListener('click', (function (n) { return function () { go(n); }; })(d));
	}
	function wait() { return parseInt(slides[index].getAttribute('data-duration'), 10) || 5000; }
	function start() { stop(); timer = setTimeout(function tick() { if (!paused && !document.hidden) { go(index + 1); } timer = setTimeout(tick, wait()); }, wait()); }
	function stop() { if (timer) clearTimeout(timer); }
	root.addEventListener('mouseenter', function () { paused = true; });
	root.addEventListener('mouseleave', function () { paused = false; });
	root.addEventListener('focusin', function () { paused = true; });
	root.addEventListener('focusout', function () { paused = false; });
	track.addEventListener('touchstart', function () { paused = true; }, { passive: true });
	track.addEventListener('touchend', function () { setTimeout(function () { paused = false; }, 4000); }, { passive: true });
	paint();
	start();
})();

/* Category strip: bring the current category into view. */
(function () {
	var cur = document.querySelector('.cat-strip__link.is-current');
	if (!cur) return;
	var list = cur.closest('.cat-strip__list');
	if (list && list.scrollWidth > list.clientWidth) {
		list.scrollLeft = cur.parentElement.offsetLeft - (list.clientWidth - cur.offsetWidth) / 2;
	}
})();

/* Product reviews: open the form, sort, show more. */
(function () {
	var box = document.querySelector('.rv');
	if (!box) return;
	var btn = box.querySelector('.rv__write');
	var form = document.getElementById('rv-form');
	if (btn && form) {
		btn.addEventListener('click', function () {
			var open = btn.getAttribute('aria-expanded') === 'true';
			btn.setAttribute('aria-expanded', open ? 'false' : 'true');
			form.hidden = open;
			if (!open) { var first = form.querySelector('input[type=radio]'); if (first) first.focus(); }
		});
	}
	var list = box.querySelector('[data-rv-list]');
	var sort = box.querySelector('[data-rv-sort]');
	var more = box.querySelector('[data-rv-more]');
	function limit(all) {
		var cards = list.children;
		for (var i = 0; i < cards.length; i++) { cards[i].hidden = !all && i >= 5; }
	}
	if (list && sort) {
		sort.addEventListener('change', function () {
			var cards = Array.prototype.slice.call(list.children);
			var by = sort.value;
			cards.sort(function (a, b) {
				var ra = +a.dataset.rating, rb = +b.dataset.rating, ta = +a.dataset.time, tb = +b.dataset.time;
				if (by === 'high') return rb - ra || tb - ta;
				if (by === 'low') return ra - rb || tb - ta;
				if (by === 'photos') return (+b.dataset.photos) - (+a.dataset.photos) || tb - ta;
				return tb - ta;
			});
			cards.forEach(function (c) { list.appendChild(c); });
			limit(!more || more.hidden);
		});
	}
	if (more && list) {
		more.addEventListener('click', function () { limit(true); more.hidden = true; });
	}
})();

/* Sale bar countdown: hides the bar when the sale ends. */
(function () {
	var bar = document.querySelector('.sale-bar[data-sale-end]');
	if (!bar) return;
	var end = parseInt(bar.getAttribute('data-sale-end'), 10);
	if (!end) return;
	var el = { d: bar.querySelector('[data-d]'), h: bar.querySelector('[data-h]'), m: bar.querySelector('[data-m]'), s: bar.querySelector('[data-s]') };
	function pad(n) { return (n < 10 ? '0' : '') + n; }
	function tick() {
		var left = Math.max(0, Math.floor((end - Date.now()) / 1000));
		if (!left) { bar.classList.add('is-ended'); clearInterval(t); return; }
		if (el.d) el.d.textContent = pad(Math.floor(left / 86400));
		if (el.h) el.h.textContent = pad(Math.floor(left % 86400 / 3600));
		if (el.m) el.m.textContent = pad(Math.floor(left % 3600 / 60));
		if (el.s) el.s.textContent = pad(left % 60);
	}
	var t = setInterval(tick, 1000);
	tick();
})();

/* Floating Home button: tap = home page (or back to top on home), drag = move it; it snaps to the nearest side and remembers the spot. */
(function () {
	var fab = document.querySelector('[data-home-fab]');
	if (!fab) return;
	var KEY = 'ayatHomeFab', M = 12, start = null, moved = false;
	function size() { return fab.offsetWidth || 60; }
	function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
	function place(x, y) { fab.style.left = x + 'px'; fab.style.top = y + 'px'; fab.style.bottom = 'auto'; fab.style.right = 'auto'; }
	function snap(save) {
		var s = size(), r = fab.getBoundingClientRect(), W = innerWidth, H = innerHeight;
		var side = (r.left + s / 2) < W / 2 ? 'l' : 'r';
		var y = clamp(r.top, M + 60, H - s - M), x = side === 'l' ? M + 2 : W - s - M - 2;
		fab.classList.add('is-snapping'); place(x, y);
		setTimeout(function () { fab.classList.remove('is-snapping'); }, 400);
		if (save) { try { localStorage.setItem(KEY, JSON.stringify({ side: side, y: y / H })); } catch (e) {} }
	}
	function restore() {
		var p = null;
		try { p = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) {}
		if (!p) return;
		var s = size(), H = innerHeight, W = innerWidth;
		place(p.side === 'r' ? W - s - M - 2 : M + 2, clamp(p.y * H, M + 60, H - s - M));
	}
	restore();
	fab.addEventListener('dragstart', function (e) { e.preventDefault(); });
	addEventListener('resize', function () { if (fab.style.top) snap(false); });
	fab.addEventListener('pointerdown', function (e) {
		if (e.button) return;
		var r = fab.getBoundingClientRect();
		start = { x: e.clientX, y: e.clientY, dx: e.clientX - r.left, dy: e.clientY - r.top, id: e.pointerId };
		moved = false;
		if (e.pointerType === 'mouse') e.preventDefault();
		try { fab.setPointerCapture(e.pointerId); } catch (err) {}
	});
	fab.addEventListener('pointermove', function (e) {
		if (!start || e.pointerId !== start.id) return;
		if (!moved && Math.abs(e.clientX - start.x) + Math.abs(e.clientY - start.y) < 8) return;
		if (!moved) { moved = true; fab.classList.add('is-dragging'); }
		var s = size();
		place(clamp(e.clientX - start.dx, 0, innerWidth - s), clamp(e.clientY - start.dy, 0, innerHeight - s));
		e.preventDefault();
	});
	function end() {
		if (!start) return;
		start = null;
		if (moved) { fab.classList.remove('is-dragging'); snap(true); }
	}
	fab.addEventListener('pointerup', end);
	fab.addEventListener('pointercancel', end);
	fab.addEventListener('click', function (e) {
		if (moved) { e.preventDefault(); moved = false; return; }
		if (fab.hasAttribute('data-is-home')) {
			e.preventDefault();
			var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
			scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
		}
	});
})();

/* Shop the Look photo slider: swipe/scroll, dots, gentle autoplay (pauses on hover/touch). */
(function () {
	var box = document.querySelector('[data-look-slides]');
	if (!box) return;
	var slides = box.children, dots = document.querySelector('[data-look-dots]');
	if (slides.length < 2 || !dots) return;
	var i = 0, timer = null, reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
	for (var k = 0; k < slides.length; k++) {
		(function (n) {
			var b = document.createElement('button');
			b.type = 'button';
			b.setAttribute('aria-label', 'Photo ' + (n + 1));
			b.addEventListener('click', function () { go(n); restart(); });
			dots.appendChild(b);
		})(k);
	}
	dots.removeAttribute('aria-hidden');
	function paint() { for (var k = 0; k < dots.children.length; k++) dots.children[k].setAttribute('aria-current', k === i ? 'true' : 'false'); }
	function go(n) { i = (n + slides.length) % slides.length; box.scrollTo({ left: i * box.clientWidth, behavior: reduce ? 'instant' : 'smooth' }); paint(); }
	box.addEventListener('scroll', function () { var n = Math.round(box.scrollLeft / Math.max(1, box.clientWidth)); if (n !== i) { i = n; paint(); } }, { passive: true });
	function stop() { clearInterval(timer); timer = null; }
	function restart() { stop(); timer = setInterval(function () { if (!document.hidden) go(i + 1); }, 3500); }
	box.addEventListener('touchstart', stop, { passive: true }); box.addEventListener('touchend', restart, { passive: true });
	box.addEventListener('keydown', function (e) { if (e.key === 'ArrowRight') { go(i + 1); e.preventDefault(); } if (e.key === 'ArrowLeft') { go(i - 1); e.preventDefault(); } });
	paint(); restart();
})();

/* Header: compact + shadow after scrolling. */
(function () {
	var h = document.querySelector('.site-header--v3');
	if (!h) return;
	var on = false;
	function check() { var s = window.scrollY > 24; if (s !== on) { on = s; h.classList.toggle('is-scrolled', s); } }
	addEventListener('scroll', check, { passive: true });
	check();
})();

/* Banner safety net: 1.8s after a banner becomes active, show it fully even if the browser paused the CSS animation. */
(function () {
	var slides = document.querySelectorAll('.ayat-slide--banner');
	if (!slides.length || !window.MutationObserver) return;
	function arm(sl) {
		clearTimeout(sl._shownT);
		sl.classList.remove('is-shown');
		if (sl.classList.contains('is-active')) sl._shownT = setTimeout(function () { sl.classList.add('is-shown'); }, 1800);
	}
	var mo = new MutationObserver(function (list) {
		list.forEach(function (m) {
			var sl = m.target, act = sl.classList.contains('is-active');
			if (act !== !!sl._wasActive) { sl._wasActive = act; arm(sl); }
		});
	});
	slides.forEach(function (sl) { sl._wasActive = sl.classList.contains('is-active'); arm(sl); mo.observe(sl, { attributes: true, attributeFilter: ['class'] }); });
})();

/* Colour swatches: card photo swap + product page select sync */
(function () {
	document.addEventListener('click', function (e) {
		var b = e.target.closest && e.target.closest('.ayat-sw--card .ayat-sw__b');
		if (!b) return;
		e.preventDefault();
		var card = b.closest('li.product') || b.closest('.product');
		if (!card) return;
		var img = card.querySelector('a.woocommerce-LoopProduct-link img, a img');
		if (img && b.dataset.src) {
			if (!img.dataset.swOrig) { img.dataset.swOrig = img.getAttribute('src') || ''; img.dataset.swOrigSet = img.getAttribute('srcset') || ''; }
			img.setAttribute('src', b.dataset.src);
			if (b.dataset.srcset) img.setAttribute('srcset', b.dataset.srcset); else img.removeAttribute('srcset');
		}
		if (b.dataset.href) card.querySelectorAll('a.woocommerce-LoopProduct-link').forEach(function (a) { a.setAttribute('href', b.dataset.href); });
		b.parentNode.querySelectorAll('.ayat-sw__b').forEach(function (x) { x.classList.toggle('is-on', x === b); x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
	});

	function selFor(group) {
		var prev = group.previousElementSibling;
		return (group.dataset.for && document.getElementById(group.dataset.for)) || (prev && prev.querySelector('select'));
	}
	function sync(group) {
		var sel = selFor(group);
		if (!sel) return;
		group.querySelectorAll('.ayat-sw__b').forEach(function (x) {
			var on = x.dataset.value === sel.value;
			x.classList.toggle('is-on', on);
			x.setAttribute('aria-checked', on ? 'true' : 'false');
			var opt = sel.querySelector('option[value="' + (window.CSS && CSS.escape ? CSS.escape(x.dataset.value) : x.dataset.value) + '"]');
			x.disabled = !opt || opt.disabled;
		});
		var row = group.closest('tr'), lab = row && row.querySelector('th label, .label label');
		if (lab) {
			var chip = lab.querySelector('.ayat-sw-chosen');
			if (!chip) { chip = document.createElement('span'); chip.className = 'ayat-sw-chosen'; lab.appendChild(chip); }
			var cur = group.querySelector('.ayat-sw__b.is-on');
			chip.textContent = cur ? '– ' + (cur.dataset.label || cur.title) : '';
		}
	}
	document.addEventListener('click', function (e) {
		var b = e.target.closest && e.target.closest('.ayat-sw--single .ayat-sw__b');
		if (!b) return;
		var group = b.closest('.ayat-sw--single'), sel = selFor(group);
		if (!sel) return;
		sel.value = sel.value === b.dataset.value ? '' : b.dataset.value;
		if (window.jQuery) window.jQuery(sel).trigger('change'); else sel.dispatchEvent(new Event('change', { bubbles: true }));
		sync(group);
	});
	function syncAll() { document.querySelectorAll('.ayat-sw--single').forEach(sync); }
	document.addEventListener('change', function (e) { if (e.target.matches && e.target.matches('.variations select')) setTimeout(syncAll, 0); });
	if (window.jQuery) window.jQuery(document.body).on('woocommerce_update_variation_values reset_data', '.variations_form', function () { setTimeout(syncAll, 0); });
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', syncAll); else syncAll();
})();

/* 3.9.0 Ring size: show the chosen size and add it to the WhatsApp order message. */
(function () {
	var box = document.querySelector('[data-ring-size]');
	if (!box) { return; }
	var chosen = box.querySelector('.ayat-size__chosen');
	var wa = document.querySelector('.pdp-wa');
	var base = wa ? wa.getAttribute('href') : '';
	box.addEventListener('change', function (e) {
		if (!e.target || e.target.name !== 'ayat_ring_size') { return; }
		var v = e.target.value;
		box.classList.remove('is-missing');
		if (chosen) { chosen.textContent = '– ' + v; }
		if (wa && base) {
			var i = base.indexOf('?text=');
			if (i > -1) {
				var msg = decodeURIComponent(base.slice(i + 6)) + ' | Ring size: ' + v;
				wa.setAttribute('href', base.slice(0, i + 6) + encodeURIComponent(msg));
			}
		}
	});
	var form = box.closest('form');
	if (form) {
		form.addEventListener('invalid', function () { box.classList.add('is-missing'); }, true);
	}
	if (wa) {
		wa.addEventListener('click', function (e) {
			if (!box.querySelector('input:checked')) {
				e.preventDefault();
				box.classList.add('is-missing');
				box.scrollIntoView({ block: 'center', behavior: 'smooth' });
			}
		});
	}
})();

/* 3.12.0 Product cards: soft reveal on scroll + second photo on hover (loaded only on hover). */
(function () {
	var cards = document.querySelectorAll('ul.products li.product');
	if (!cards.length) { return; }
	var still = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
	if (!still && 'IntersectionObserver' in window) {
		document.documentElement.classList.add('js-cards');
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) {
				if (!en.isIntersecting) { return; }
				en.target.classList.add('is-in');
				io.unobserve(en.target);
			});
		}, { rootMargin: '0px 0px -6% 0px' });
		cards.forEach(function (li, i) {
			var list = li.parentElement, idx = Array.prototype.indexOf.call(list.children, li);
			li.style.setProperty('--ayat-d', ((idx % 4) * 70) + 'ms');
			io.observe(li);
		});
		// Safety: never leave a card hidden.
		setTimeout(function () { cards.forEach(function (li) { li.classList.add('is-in'); }); }, 4000);
	}
	function load(li) {
		var alt = li.querySelector('.ayat-card-alt[data-src]');
		if (!alt) { return; }
		alt.addEventListener('load', function () { alt.classList.add('is-ready'); }, { once: true });
		if (alt.dataset.srcset) { alt.srcset = alt.dataset.srcset; }
		alt.src = alt.dataset.src;
		alt.removeAttribute('data-src');
	}
	if (window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches) {
		cards.forEach(function (li) { li.addEventListener('pointerenter', function () { load(li); }, { once: true }); });
		return;
	}
	// Phones/tablets: no mouse, so the photo gently swaps by itself while the card is on screen.
	if (still || !('IntersectionObserver' in window)) { return; }
	var timers = new WeakMap();
	function start(li) {
		if (timers.has(li)) { return; }
		load(li);
		var media = li.querySelector('.ayat-card-media');
		if (!media || !media.querySelector('.ayat-card-alt')) { return; }
		timers.set(li, setInterval(function () { media.classList.toggle('is-flip'); }, 2600));
	}
	function stop(li) {
		var t = timers.get(li);
		if (t) { clearInterval(t); timers.delete(li); }
		var media = li.querySelector('.ayat-card-media');
		if (media) { media.classList.remove('is-flip'); }
	}
	function watch() {
		var seen = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) { if (en.isIntersecting) { start(en.target); } else { stop(en.target); } });
		}, { threshold: 0.6 });
		cards.forEach(function (li) { if (li.querySelector('.ayat-card-alt')) { seen.observe(li); } });
	}
	// Wait until the page has finished loading so the first view stays fast.
	if (document.readyState === 'complete') { setTimeout(watch, 600); } else { window.addEventListener('load', function () { setTimeout(watch, 600); }); }
})();

/* 3.17.4 Outside links (Instagram, Facebook, TikTok, WhatsApp, YouTube…) open in a new tab so shaya.pk stays open. */
(function () {
	function mark(a) {
		if (!a || !a.href || a.target === '_blank') { return; }
		var u;
		try { u = new URL(a.href, location.href); } catch (err) { return; }
		if (!/^https?:$/.test(u.protocol) || u.host === location.host) { return; }
		a.target = '_blank';
		var rel = (a.getAttribute('rel') || '').split(/\s+/);
		['noopener', 'noreferrer'].forEach(function (r) { if (rel.indexOf(r) < 0) { rel.push(r); } });
		a.setAttribute('rel', rel.join(' ').trim());
	}
	function all() { document.querySelectorAll('a[href]').forEach(mark); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', all); } else { all(); }
	// Links added later (menus, popups) are handled on click.
	document.addEventListener('click', function (e) { var a = e.target.closest && e.target.closest('a[href]'); if (a) { mark(a); } }, true);
})();
