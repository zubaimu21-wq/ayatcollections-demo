<?php
/**
 * Homepage: jewellery-box hero, collections, new arrivals, shop the look, trust strip.
 * Texts and photos: Appearance → Customize → Homepage.
 *
 * @package Ayatcollections
 */

defined( 'ABSPATH' ) || exit;

get_header();

$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
$arrivals = get_page_by_path( 'new-arrivals' );

// Every collection (category) with products, in the order set in Products → Categories.
$terms = ayat_get_collections();
if ( ! $terms ) {
	$terms = array();
}

// Shop the look products.
$look = array();
if ( function_exists( 'wc_get_product' ) ) {
	foreach ( array_filter( array_map( 'trim', explode( ',', (string) ayat_home( 'look_products' ) ) ) ) as $slug ) {
		$post = get_page_by_path( sanitize_title( $slug ), OBJECT, 'product' );
		$prod = $post ? wc_get_product( $post ) : null;
		if ( $prod && $prod->is_visible() ) {
			$look[] = $prod;
		}
	}
}
?>
<main id="main" class="site-main home-main">

	<h1 class="screen-reader-text"><?php echo esc_html( get_bloginfo( 'name' ) . ' – ' . __( 'gold-tone stainless steel jewellery', 'ayatcollections' ) ); ?></h1>

	<section class="ayat-slider ayat-slider--banners" data-slider aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured collections', 'ayatcollections' ); ?>">
		<div class="ayat-slider__track" data-slider-track>
			<?php
			$ayat_banners = array();
			for ( $s = 1; $s <= 6; $s++ ) {
				$b_id   = absint( get_theme_mod( 'ayat_home_banner' . $s . '_img_id', 0 ) );
				$b_file = (string) ayat_home( 'banner' . $s . '_img' );
				if ( $b_id || '' !== $b_file ) {
					$ayat_banners[] = array( 'n' => $s, 'id' => $b_id, 'file' => $b_file );
				}
			}
			$ayat_bcount = count( $ayat_banners );
			?>
			<?php foreach ( $ayat_banners as $b_pos => $ayat_b ) : ?>
				<?php
				$s      = $ayat_b['n'];
				$b_link = trim( (string) ayat_home( 'banner' . $s . '_link' ) );
				$b_term = ( $b_link && false === strpos( $b_link, '/' ) ) ? get_term_by( 'slug', $b_link, 'product_cat' ) : false;
				if ( $b_term && ! is_wp_error( $b_term ) ) {
					$b_url = get_term_link( $b_term );
				} elseif ( $b_link && function_exists( 'ayat_resolve_link' ) ) {
					$b_url = ayat_resolve_link( $b_link );
				} else {
					$b_url = $shop_url;
				}
				$b_alt  = (string) ayat_home( 'banner' . $s . '_alt' );
				$b_id   = $ayat_b['id'];
				$b_load = 0 === $b_pos ? array( 'loading' => 'eager', 'fetchpriority' => 'high' ) : array( 'loading' => 'eager' );
				?>
				<div class="ayat-slide ayat-slide--banner" role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr( ( $b_pos + 1 ) . ' / ' . $ayat_bcount ); ?>">
					<a class="ayat-banner" href="<?php echo esc_url( $b_url ); ?>">
						<?php
						if ( $b_id ) {
							echo wp_get_attachment_image( $b_id, 'full', false, array_merge( $b_load, array( 'class' => 'ayat-banner__img', 'alt' => $b_alt, 'sizes' => '100vw' ) ) );
						} else {
							$b_base = AYAT_URI . '/assets/images/demo/' . $ayat_b['file'];
							printf(
								'<img class="ayat-banner__img" src="%1$s.webp" srcset="%1$s-m.webp 1000w, %1$s.webp 1983w" sizes="100vw" width="1983" height="793" alt="%2$s" loading="eager"%3$s decoding="async">',
								esc_url( $b_base ),
								esc_attr( $b_alt ),
								0 === $b_pos ? ' fetchpriority="high"' : ''
							);
						}
						?>
						<?php
						$b_title  = trim( (string) ayat_home( 'banner' . $s . '_title' ) );
						$b_kicker = trim( (string) ayat_home( 'banner' . $s . '_kicker' ) );
						$b_btn    = trim( (string) ayat_home( 'banner' . $s . '_btn' ) );
						if ( '' !== $b_title ) :
							?>
							<span class="ayat-banner__copy">
								<span class="ayat-banner__brand" aria-hidden="true">SHAYA<small><?php esc_html_e( 'By Aayat Collections', 'ayatcollections' ); ?></small></span>
								<?php if ( $b_kicker ) : ?><span class="ayat-banner__kicker"><?php echo esc_html( $b_kicker ); ?></span><?php endif; ?>
								<span class="ayat-banner__title"><?php echo esc_html( $b_title ); ?></span>
								<span class="ayat-banner__line" aria-hidden="true"></span>
								<?php if ( $b_btn ) : ?><span class="ayat-banner__btn"><?php echo esc_html( $b_btn ); ?> <span aria-hidden="true">&rarr;</span></span><?php endif; ?>
							</span>
						<?php endif; ?>
						<span class="ayat-banner__shine" aria-hidden="true"></span>
					</a>
				</div>
			<?php endforeach; ?>
		</div>
		<button class="ayat-slider__nav ayat-slider__nav--prev" type="button" data-slider-prev aria-label="<?php esc_attr_e( 'Previous banner', 'ayatcollections' ); ?>">&#8249;</button>
		<button class="ayat-slider__nav ayat-slider__nav--next" type="button" data-slider-next aria-label="<?php esc_attr_e( 'Next banner', 'ayatcollections' ); ?>">&#8250;</button>
		<div class="ayat-slider__dots" data-slider-dots>
			<?php for ( $s = 1; $s <= $ayat_bcount; $s++ ) : ?>
				<button type="button" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: banner number */ __( 'Go to banner %d', 'ayatcollections' ), $s ) ); ?>"<?php echo 1 === $s ? ' aria-current="true"' : ''; ?>></button>
			<?php endfor; ?>
		</div>
	</section>


	<?php if ( function_exists( 'ayat_sale_section' ) ) { ayat_sale_section(); } ?>

	<section class="home-sec" id="collections" aria-labelledby="col-title">
		<div class="wrap">
			<div class="sec-head" data-reveal>
				<h2 id="col-title"><?php echo esc_html( ayat_home( 'col_title' ) ); ?></h2>
				<a class="link-gold" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'View all', 'ayatcollections' ); ?></a>
			</div>
			<ul class="cat-rounds" role="list">
				<?php foreach ( $terms as $term ) : ?>
					<?php $img = ayat_collection_image_id( $term ); ?>
					<li>
						<a href="<?php echo esc_url( get_term_link( $term ) ); ?>" class="cat-rounds__link">
							<span class="cat-rounds__img"><?php echo $img ? wp_get_attachment_image( $img, 'woocommerce_thumbnail', false, array( 'alt' => '', 'loading' => 'lazy' ) ) : '<span class="cat-rounds__initial" aria-hidden="true">' . esc_html( mb_substr( $term->name, 0, 1 ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<span class="cat-rounds__name"><?php echo esc_html( $term->name ); ?></span>
							<?php /* translators: %d: number of products */ ?>
							<span class="cat-rounds__count"><?php echo esc_html( sprintf( _n( '%d piece', '%d pieces', (int) $term->count, 'ayatcollections' ), (int) $term->count ) ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<?php if ( class_exists( 'WooCommerce' ) ) : ?>
		<section class="home-sec home-sec--gold home-products" id="shop-now" aria-labelledby="new-title">
			<div class="wrap">
				<div class="sec-head" data-reveal>
					<h2 id="new-title"><?php echo esc_html( ayat_home( 'new_title' ) ); ?></h2>
					<a class="link-gold" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Shop all', 'ayatcollections' ); ?></a>
				</div>
				<div class="all-rounds"><?php echo do_shortcode( '[products limit="-1" columns="4" orderby="menu_order title" order="ASC" visibility="visible"]' ); ?></div>
			</div>
		</section>
	<?php endif; ?>

	<section class="home-sec models" aria-labelledby="models-title">
		<div class="wrap">
			<div class="sec-head sec-head--center">
				<p class="eyebrow"><?php esc_html_e( 'Lookbook', 'ayatcollections' ); ?></p>
				<h2 id="models-title"><?php echo esc_html( ayat_home( 'models_title' ) ); ?></h2>
				<p class="models__intro"><?php esc_html_e( 'Everyday elegance, modestly styled – tap a look to shop it.', 'ayatcollections' ); ?></p>
			</div>
			<div class="models__ribbon" aria-label="<?php esc_attr_e( 'Why SHAYA', 'ayatcollections' ); ?>">
				<?php
				$promises = array( __( 'Anti-tarnish finish', 'ayatcollections' ), __( 'Waterproof stainless steel', 'ayatcollections' ), __( 'Cash on delivery all over Pakistan', 'ayatcollections' ), __( 'Gift-ready SHAYA box', 'ayatcollections' ), __( '7-day easy exchange', 'ayatcollections' ) );
				?>
				<div class="models__ribbon-track">
					<?php for ( $r = 0; $r < 2; $r++ ) : ?>
						<ul class="models__ribbon-list" role="list"<?php echo $r ? ' aria-hidden="true"' : ''; ?>>
							<?php foreach ( $promises as $pr ) : ?>
								<li><span class="models__ribbon-gem" aria-hidden="true">&#10022;</span><?php echo esc_html( $pr ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endfor; ?>
				</div>
			</div>
			<ul class="models__list" role="list">
				<?php for ( $m = 1; $m <= 6; $m++ ) : ?>
					<?php
					if ( '' === trim( (string) ayat_home( 'model' . $m . '_label' ) ) ) {
						continue;
					}
					$m_term = get_term_by( 'slug', ayat_home( 'model' . $m . '_cat' ), 'product_cat' );
					$m_url  = $m_term && ! is_wp_error( $m_term ) ? get_term_link( $m_term ) : $shop_url;
					$m_info = function_exists( 'ayat_look_info' ) ? ayat_look_info( $m_term ) : array( 'count' => 0, 'from' => '' );
					?>
					<li>
						<a class="models__card" href="<?php echo esc_url( $m_url ); ?>">
							<?php echo ayat_home_img( 'model' . $m . '_img', ayat_home( 'model' . $m . '_label' ), 'models__img' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span class="models__no" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', $m ) ); ?></span>
							<span class="models__panel">
								<span class="models__eyebrow">
									<?php
									/* translators: %d: look number */
									echo esc_html( sprintf( __( 'Look %02d', 'ayatcollections' ), $m ) );
									if ( $m_info['count'] ) {
										/* translators: %d: number of designs */
										echo ' · ' . esc_html( sprintf( _n( '%d design', '%d designs', $m_info['count'], 'ayatcollections' ), $m_info['count'] ) );
									}
									?>
								</span>
								<span class="models__label"><?php echo esc_html( ayat_home( 'model' . $m . '_label' ) ); ?> <span aria-hidden="true">&rarr;</span></span>
								<?php if ( $m_info['from'] ) : ?>
									<span class="models__from"><?php echo esc_html( sprintf( /* translators: %s: price */ __( 'From %s', 'ayatcollections' ), $m_info['from'] ) ); ?></span>
								<?php endif; ?>
								<span class="models__cta"><?php esc_html_e( 'Shop the look', 'ayatcollections' ); ?></span>
							</span>
						</a>
					</li>
				<?php endfor; ?>
			</ul>
			<p class="models__note"><?php esc_html_e( 'Looks styled on AI-generated models for illustration.', 'ayatcollections' ); ?></p>
			<p class="models__more"><a class="models__more-link" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Explore the full collection', 'ayatcollections' ); ?> <span aria-hidden="true">&rarr;</span></a></p>
		</div>
	</section>

	<?php if ( $look ) : ?>
		<section class="home-sec look" aria-labelledby="look-title">
			<div class="wrap look__inner">
				<figure class="look__media" data-reveal>
					<div class="look__slides" data-look-slides tabindex="0" aria-label="<?php esc_attr_e( 'Photos of this look', 'ayatcollections' ); ?>">
						<div class="look__slide"><?php echo ayat_home_img( 'look_img', ayat_home( 'look_title' ), 'look__img' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
						<?php foreach ( array_values( $look ) as $look_i => $prod ) : ?>
							<?php
							$look_key  = 'look_img' . ( $look_i + 2 );
							$look_pic  = ( $look_i < 3 && ayat_home( $look_key ) ) ? str_replace( 'loading="lazy"', 'loading="eager"', ayat_home_img( $look_key, $prod->get_name(), 'look__img' ) ) : '';
							$look_flat = ! $look_pic;
							if ( $look_flat && $prod->get_image_id() ) {
								$look_pic = wp_get_attachment_image( $prod->get_image_id(), 'large', false, array( 'class' => 'look__img', 'loading' => 'eager', 'alt' => $prod->get_name() ) );
							}
							if ( ! $look_pic ) {
								continue;
							}
							?>
							<a class="look__slide<?php echo $look_flat ? ' look__slide--product' : ' look__slide--styled'; ?>" href="<?php echo esc_url( $prod->get_permalink() ); ?>">
								<?php echo $look_pic; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span class="look__slide-name"><?php echo esc_html( $prod->get_name() ); ?></span>
							</a>
						<?php endforeach; ?>
					</div>
					<div class="look__dots" data-look-dots aria-hidden="true"></div>
					<figcaption class="look__badge"><span class="look__badge-n"><?php echo esc_html( count( $look ) ); ?></span><span class="look__badge-t"><?php esc_html_e( 'pieces', 'ayatcollections' ); ?></span></figcaption>
				</figure>
				<div class="look__copy" data-reveal>
					<p class="eyebrow"><?php esc_html_e( 'Shop the Look', 'ayatcollections' ); ?></p>
					<h2 id="look-title"><?php echo esc_html( ayat_home( 'look_title' ) ); ?></h2>
					<p><?php echo esc_html( ayat_home( 'look_text' ) ); ?></p>
					<ol class="look__list">
						<?php foreach ( $look as $prod ) : ?>
							<li>
								<a href="<?php echo esc_url( $prod->get_permalink() ); ?>">
									<?php echo $prod->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<span class="look__name"><?php echo esc_html( $prod->get_name() ); ?></span>
									<span class="look__price"><?php echo wp_kses_post( $prod->get_price_html() ); ?></span>
									<span class="look__go" aria-hidden="true">&rarr;</span>
								</a>
							</li>
						<?php endforeach; ?>
					</ol>
					<?php
					$look_total = 0;
					foreach ( $look as $prod ) {
						$look_total += (float) wc_get_price_to_display( $prod );
					}
					?>
					<div class="look__foot">
						<p class="look__total"><span><?php esc_html_e( 'Complete the look', 'ayatcollections' ); ?></span><strong><?php echo wp_kses_post( wc_price( $look_total ) ); ?></strong></p>
						<a class="btn btn--gold look__btn" href="<?php echo esc_url( $look[0]->get_permalink() ); ?>"><?php esc_html_e( 'Shop the set', 'ayatcollections' ); ?></a>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php
	$reviews   = function_exists( 'ayat_get_reviews' ) ? ayat_get_reviews( 0, 6 ) : array();
	$rev_short = trim( (string) ayat_home( 'rev_shortcode' ) );
	?>
	<?php if ( $reviews || $rev_short ) : ?>
		<section class="home-sec reviews" aria-labelledby="rev-title">
			<div class="wrap">
				<div class="sec-head sec-head--center">
					<h2 id="rev-title"><?php echo esc_html( ayat_home( 'rev_title' ) ); ?></h2>
					<p><?php echo esc_html( ayat_home( 'rev_text' ) ); ?></p>
				</div>
				<?php echo function_exists( 'ayat_rr_banner' ) ? ayat_rr_banner( 'home' ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php
				if ( $reviews ) {
					ayat_render_reviews( $reviews );
				}
				if ( $rev_short ) {
					echo '<div class="reviews__widget">' . do_shortcode( $rev_short ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				?>
			</div>
		</section>
	<?php endif; ?>

	<section class="perks" aria-label="<?php esc_attr_e( 'Why shop with us', 'ayatcollections' ); ?>">
		<ul class="wrap perks__list" role="list">
			<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 7h12v9H2zM14 10h4l3 3v3h-7M5.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM17.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"/></svg><span><strong><?php esc_html_e( 'Cash on Delivery', 'ayatcollections' ); ?></strong><?php esc_html_e( 'Across Pakistan', 'ayatcollections' ); ?></span></li>
			<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 6v6c0 4.5 3.4 8 8 9 4.6-1 8-4.5 8-9V6l-8-3Z"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg><span><strong><?php esc_html_e( 'Secure Shopping', 'ayatcollections' ); ?></strong><?php esc_html_e( 'Your trust matters', 'ayatcollections' ); ?></span></li>
			<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5zM3 7.5 12 12l9-4.5M12 12v9"/></svg><span><strong><?php esc_html_e( 'Gift Boxed', 'ayatcollections' ); ?></strong><?php esc_html_e( 'Easy exchange', 'ayatcollections' ); ?></span></li>
			<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14h3v5H4zM17 14h3v5h-3zM20 19c0 1.5-2 2-5 2"/></svg><span><strong><?php esc_html_e( 'WhatsApp Support', 'ayatcollections' ); ?></strong><?php esc_html_e( 'Help before you order', 'ayatcollections' ); ?></span></li>
		</ul>
	</section>
</main>
<?php
get_footer();
