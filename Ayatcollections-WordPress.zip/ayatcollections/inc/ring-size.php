<?php
/**
 * Ring size picker.
 *
 * Every product in the "Rings" category (or a sub-category of it) gets a
 * required "Ring size" choice on its page. The chosen size travels to the bag,
 * checkout, the order (admin + emails) and the WhatsApp order message.
 * Nothing to set up per product.
 *
 * @package Ayatcollections
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sizes offered.
 *
 * @return string[]
 */
function ayat_ring_sizes( $product = null ) {
	$sizes   = array( '6', '7', '8' );
	$product = $product ? wc_get_product( $product ) : null;
	if ( $product ) {
		$id     = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
		$custom = trim( (string) get_post_meta( $id, '_ayat_ring_sizes', true ) );
		if ( '' !== $custom ) {
			$sizes = array_values( array_unique( array_filter( array_map( 'trim', preg_split( '/[,|\/]+/', $custom ) ), 'strlen' ) ) );
		}
	}
	return apply_filters( 'ayat_ring_sizes', $sizes, $product );
}

/**
 * "Ring sizes" box on the product edit screen (General tab).
 * Empty = 6, 7, 8. Type "none" to switch the size choice off for a product.
 */
function ayat_ring_sizes_admin_field() {
	woocommerce_wp_text_input(
		array(
			'id'          => '_ayat_ring_sizes',
			'label'       => __( 'Ring sizes', 'ayatcollections' ),
			'placeholder' => '6, 7, 8',
			'desc_tip'    => true,
			'description' => __( 'Only for products in Rings. Sizes separated by commas, e.g. 5, 6, 7, 8, 9. Leave empty for 6, 7, 8. Type none to hide the size choice.', 'ayatcollections' ),
		)
	);
}
add_action( 'woocommerce_product_options_general_product_data', 'ayat_ring_sizes_admin_field' );

/**
 * Save the ring sizes box.
 *
 * @param WC_Product $product Product.
 */
function ayat_ring_sizes_admin_save( $product ) {
	if ( isset( $_POST['_ayat_ring_sizes'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$product->update_meta_data( '_ayat_ring_sizes', sanitize_text_field( wp_unslash( $_POST['_ayat_ring_sizes'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}
}
add_action( 'woocommerce_admin_process_product_object', 'ayat_ring_sizes_admin_save' );

/**
 * Does this product need a ring size?
 * Skips variable products that already have their own size attribute.
 *
 * @param WC_Product|int $product Product.
 * @return bool
 */
function ayat_needs_ring_size( $product ) {
	$product = wc_get_product( $product );
	if ( ! $product ) {
		return false;
	}
	$id = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
	if ( 'none' === strtolower( trim( (string) get_post_meta( $id, '_ayat_ring_sizes', true ) ) ) ) {
		return false;
	}
	$parent = wc_get_product( $id );
	if ( $parent && $parent->is_type( 'variable' ) ) {
		foreach ( array_keys( $parent->get_variation_attributes() ) as $att ) {
			if ( preg_match( '/size|naap/i', $att . ' ' . wc_attribute_label( $att ) ) ) {
				return false;
			}
		}
	}
	$rings = get_term_by( 'slug', 'rings', 'product_cat' );
	if ( ! $rings ) {
		return false;
	}
	foreach ( wc_get_product_term_ids( $id, 'product_cat' ) as $term_id ) {
		if ( (int) $term_id === (int) $rings->term_id || term_is_ancestor_of( $rings->term_id, $term_id, 'product_cat' ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Size buttons above "Add to Bag".
 */
function ayat_ring_size_field() {
	global $product;
	if ( ! ayat_needs_ring_size( $product ) ) {
		return;
	}
	echo '<fieldset class="ayat-size" data-ring-size>';
	echo '<legend class="ayat-size__label">' . esc_html__( 'Ring size', 'ayatcollections' ) . ' <span class="ayat-size__chosen" aria-live="polite"></span></legend>';
	echo '<div class="ayat-size__opts">';
	foreach ( ayat_ring_sizes( $product ) as $size ) {
		printf(
			'<label class="ayat-size__opt"><input type="radio" name="ayat_ring_size" value="%1$s" required><span>%2$s</span></label>',
			esc_attr( $size ),
			esc_html( $size )
		);
	}
	echo '</div>';
	echo '<p class="ayat-size__hint">' . esc_html__( 'Choose your ring size before adding to bag.', 'ayatcollections' ) . '</p>';
	echo '</fieldset>';
}
add_action( 'woocommerce_before_add_to_cart_button', 'ayat_ring_size_field', 5 );

/**
 * Size is required.
 *
 * @param bool $ok         Passed so far.
 * @param int  $product_id Product.
 * @return bool
 */
function ayat_ring_size_validate( $ok, $product_id ) {
	if ( ! $ok || ! ayat_needs_ring_size( $product_id ) ) {
		return $ok;
	}
	$size = isset( $_POST['ayat_ring_size'] ) ? sanitize_text_field( wp_unslash( $_POST['ayat_ring_size'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( ! in_array( $size, ayat_ring_sizes( $product_id ), true ) ) {
		wc_add_notice( __( 'Please choose a ring size.', 'ayatcollections' ), 'error' );
		return false;
	}
	return $ok;
}
add_filter( 'woocommerce_add_to_cart_validation', 'ayat_ring_size_validate', 10, 2 );

/**
 * Keep the size with the bag item (different sizes = separate lines).
 *
 * @param array $data       Item data.
 * @param int   $product_id Product.
 * @return array
 */
function ayat_ring_size_cart_data( $data, $product_id ) {
	if ( isset( $_POST['ayat_ring_size'] ) && ayat_needs_ring_size( $product_id ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$size = sanitize_text_field( wp_unslash( $_POST['ayat_ring_size'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( in_array( $size, ayat_ring_sizes( $product_id ), true ) ) {
			$data['ayat_ring_size'] = $size;
		}
	}
	return $data;
}
add_filter( 'woocommerce_add_cart_item_data', 'ayat_ring_size_cart_data', 10, 2 );

/**
 * Show the size in the bag and at checkout.
 *
 * @param array $item_data Display data.
 * @param array $item      Cart item.
 * @return array
 */
function ayat_ring_size_item_data( $item_data, $item ) {
	if ( ! empty( $item['ayat_ring_size'] ) ) {
		$item_data[] = array(
			'key'   => __( 'Ring size', 'ayatcollections' ),
			'value' => $item['ayat_ring_size'],
		);
	}
	return $item_data;
}
add_filter( 'woocommerce_get_item_data', 'ayat_ring_size_item_data', 10, 2 );

/**
 * Save the size on the order line (shows in admin and emails).
 *
 * @param WC_Order_Item_Product $item   Line item.
 * @param string                $key    Cart key.
 * @param array                 $values Cart item.
 */
function ayat_ring_size_order_item( $item, $key, $values ) {
	if ( ! empty( $values['ayat_ring_size'] ) ) {
		$item->add_meta_data( __( 'Ring size', 'ayatcollections' ), $values['ayat_ring_size'], true );
	}
}
add_action( 'woocommerce_checkout_create_order_line_item', 'ayat_ring_size_order_item', 10, 3 );

/**
 * On product cards a ring opens its page to pick a size instead of adding
 * straight to the bag.
 *
 * @param string     $html    Button HTML.
 * @param WC_Product $product Product.
 * @return string
 */
function ayat_ring_size_loop_button( $html, $product ) {
	if ( ! $product->is_type( 'simple' ) || ! $product->is_purchasable() || ! $product->is_in_stock() || ! ayat_needs_ring_size( $product ) ) {
		return $html;
	}
	return sprintf(
		'<a href="%1$s" class="button product_type_simple ayat-choose-size" aria-label="%2$s">%3$s</a>',
		esc_url( $product->get_permalink() ),
		/* translators: %s: product name */
		esc_attr( sprintf( __( 'Choose size for “%s”', 'ayatcollections' ), $product->get_name() ) ),
		esc_html__( 'Choose Size', 'ayatcollections' )
	);
}
add_filter( 'woocommerce_loop_add_to_cart_link', 'ayat_ring_size_loop_button', 20, 2 );
