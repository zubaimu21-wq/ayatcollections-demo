<?php
/**
 * Product cards: the photo sits in a frame so it can zoom gently on hover,
 * and the product's second photo fades in on hover (laptop/desktop only).
 * The second photo is not downloaded until someone actually hovers the card,
 * so pages load exactly as fast as before.
 *
 * @package Ayatcollections
 */

defined( 'ABSPATH' ) || exit;

remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );

/**
 * Card photo + (lazy) hover photo.
 */
function ayat_card_media() {
	global $product;
	echo '<span class="ayat-card-media">';
	woocommerce_template_loop_product_thumbnail();
	if ( $product ) {
		$main = (int) $product->get_image_id();
		foreach ( $product->get_gallery_image_ids() as $id ) {
			$id = (int) $id;
			if ( $id && $id !== $main ) {
				$src = wp_get_attachment_image_url( $id, 'woocommerce_thumbnail' );
				if ( $src ) {
					printf(
						'<img class="ayat-card-alt" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="%1$s" data-srcset="%2$s" sizes="(max-width: 600px) 50vw, 300px" alt="" aria-hidden="true" decoding="async" width="600" height="600">',
						esc_url( $src ),
						esc_attr( (string) wp_get_attachment_image_srcset( $id, 'woocommerce_thumbnail' ) )
					);
				}
				break;
			}
		}
	}
	echo '</span>';
}
add_action( 'woocommerce_before_shop_loop_item_title', 'ayat_card_media', 10 );
