<?php
/**
 * Smarter product search.
 *
 * WordPress searches letters inside any text, so "ring" also finds "earring"
 * and descriptions, and a small typo ("braclate") finds nothing. This search:
 * - matches whole words in the product name, category and tags;
 * - understands common spellings and Urdu words (braclate, kara, jhumka, payal…);
 * - forgives small typos;
 * - shows the best matches first (name > category > description).
 *
 * @package Ayatcollections
 */

defined( 'ABSPATH' ) || exit;

/**
 * Word → category slug.
 *
 * @return array
 */
function ayat_ss_synonyms() {
	return apply_filters(
		'ayat_ss_synonyms',
		array(
			'ring'      => 'rings', 'anguthi' => 'rings', 'angoothi' => 'rings', 'chhalla' => 'rings', 'challa' => 'rings',
			'bracelet'  => 'bracelets', 'braclet' => 'bracelets', 'braclate' => 'bracelets', 'bracelate' => 'bracelets', 'breslet' => 'bracelets', 'brecelet' => 'bracelets', 'bracelt' => 'bracelets', 'bangle' => 'bracelets', 'bangal' => 'bracelets', 'churi' => 'bracelets', 'choori' => 'bracelets',
			'earring'   => 'earrings', 'earing' => 'earrings', 'earings' => 'earrings', 'jhumka' => 'earrings', 'jhumki' => 'earrings', 'bali' => 'earrings', 'baliyan' => 'earrings', 'tops' => 'earrings', 'hoop' => 'earrings', 'drop' => 'earrings',
			'stud'      => 'studs',
			'necklace'  => 'necklaces', 'neckless' => 'necklaces', 'necklas' => 'necklaces', 'neklace' => 'necklaces', 'nekles' => 'necklaces', 'chain' => 'necklaces', 'haar' => 'necklaces', 'har' => 'necklaces', 'pendant' => 'necklaces', 'locket' => 'necklaces', 'choker' => 'necklaces', 'mala' => 'necklaces',
			'anklet'    => 'anklets', 'payal' => 'anklets', 'pazeb' => 'anklets', 'paayal' => 'anklets',
			'cuff'      => 'hand-cuffs', 'kara' => 'hand-cuffs', 'kada' => 'hand-cuffs', 'karra' => 'hand-cuffs',
			'adjustable' => 'adjustable-hand-cuffs',
			'nose'      => 'nose-rings', 'nath' => 'nose-rings', 'koka' => 'nose-rings', 'nosepin' => 'nose-rings',
			'set'       => 'combo-sets', 'combo' => 'combo-sets',
			'charm'     => 'charms',
			'anja'      => 'anja', 'handchain' => 'anja',
			'permanent' => 'permanent-bracelets',
		)
	);
}

/**
 * Lowercase, split into words, drop plural "s".
 *
 * @param string $text Text.
 * @return string[]
 */
function ayat_ss_words( $text ) {
	$text  = strtolower( remove_accents( wp_strip_all_tags( (string) $text ) ) );
	$text  = str_replace( array( '-', '_', '/', '&' ), ' ', $text );
	$words = preg_split( '/[^a-z0-9]+/', $text, -1, PREG_SPLIT_NO_EMPTY );
	$out   = array();
	foreach ( $words as $w ) {
		if ( strlen( $w ) > 3 && 's' === substr( $w, -1 ) && 'ss' !== substr( $w, -2 ) ) {
			$w = substr( $w, 0, -1 );
		}
		$out[] = $w;
	}
	return $out;
}

/**
 * Do two words match (exact, or a small typo for longer words)?
 *
 * @param string $a Query word.
 * @param string $b Product word.
 * @return int 2 exact, 1 close, 0 no.
 */
function ayat_ss_match( $a, $b ) {
	if ( $a === $b ) {
		return 2;
	}
	$len = strlen( $a );
	if ( $len >= 5 && strlen( $b ) >= 4 && abs( $len - strlen( $b ) ) <= 2 && levenshtein( $a, $b ) <= ( $len >= 8 ? 2 : 1 ) ) {
		return 1;
	}
	// Word start, e.g. "neck" → "necklace" (not "ring" inside "earring").
	if ( $len >= 4 && 0 === strpos( $b, $a ) ) {
		return 1;
	}
	return 0;
}

/**
 * Searchable index of published products (cached for 1 hour).
 *
 * @return array id => [ title words, category slugs, category words, other words ]
 */
function ayat_ss_index() {
	$index = get_transient( 'ayat_ss_index' );
	if ( is_array( $index ) ) {
		return $index;
	}
	$index = array();
	$ids   = get_posts(
		array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 2000,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	foreach ( $ids as $id ) {
		$cats  = wp_get_post_terms( $id, 'product_cat' );
		$tags  = wp_get_post_terms( $id, 'product_tag', array( 'fields' => 'names' ) );
		$slugs = array();
		$cw    = array();
		foreach ( is_array( $cats ) ? $cats : array() as $c ) {
			$slugs[] = $c->slug;
			$cw      = array_merge( $cw, ayat_ss_words( $c->name ) );
		}
		$post          = get_post( $id );
		$index[ $id ] = array(
			array_values( array_unique( ayat_ss_words( get_the_title( $id ) ) ) ),
			$slugs,
			array_values( array_unique( $cw ) ),
			array_values( array_unique( ayat_ss_words( ( is_array( $tags ) ? implode( ' ', $tags ) : '' ) . ' ' . ( $post ? $post->post_excerpt : '' ) . ' ' . get_post_meta( $id, '_sku', true ) ) ) ),
		);
	}
	set_transient( 'ayat_ss_index', $index, HOUR_IN_SECONDS );
	return $index;
}

/**
 * Forget the index when products or categories change.
 */
function ayat_ss_flush() {
	delete_transient( 'ayat_ss_index' );
}
add_action( 'save_post_product', 'ayat_ss_flush' );
add_action( 'woocommerce_update_product', 'ayat_ss_flush' );
add_action( 'edited_product_cat', 'ayat_ss_flush' );
add_action( 'deleted_post', 'ayat_ss_flush' );

/**
 * Product ids for a search, best first.
 *
 * @param string $query Search text.
 * @return int[]
 */
function ayat_ss_results( $query ) {
	$words = ayat_ss_words( $query );
	$stop  = array( 'for', 'and', 'the', 'with', 'women', 'woman', 'girl', 'ladies', 'lady', 'of', 'in', 'ka', 'ki', 'ke', 'aur' );
	$words = array_values( array_diff( $words, $stop ) );
	if ( ! $words ) {
		return array();
	}
	$syn    = ayat_ss_synonyms();
	$scores = array();
	foreach ( ayat_ss_index() as $id => $row ) {
		list( $tw, $slugs, $cw, $ow ) = $row;
		$total = 0;
		$hit   = 0;
		foreach ( $words as $q ) {
			$best = 0;
			// Category by synonym / spelling.
			$cat = isset( $syn[ $q ] ) ? $syn[ $q ] : '';
			if ( ! $cat ) {
				foreach ( $syn as $k => $v ) {
					if ( strlen( $q ) >= 5 && levenshtein( $q, $k ) <= 2 ) {
						$cat = $v;
						break;
					}
				}
			}
			if ( $cat && in_array( $cat, $slugs, true ) ) {
				$best = max( $best, 12 );
			}
			foreach ( $tw as $w ) {
				$m = ayat_ss_match( $q, $w );
				if ( $m ) {
					$best = max( $best, 2 === $m ? 10 : 6 );
				}
			}
			foreach ( $cw as $w ) {
				$m = ayat_ss_match( $q, $w );
				if ( $m ) {
					$best = max( $best, 2 === $m ? 8 : 5 );
				}
			}
			foreach ( $ow as $w ) {
				if ( ayat_ss_match( $q, $w ) ) {
					$best = max( $best, 3 );
				}
			}
			if ( $best ) {
				++$hit;
			}
			$total += $best;
		}
		// Every word should match something (so "gold ring" does not show gold bracelets).
		if ( $hit === count( $words ) || ( count( $words ) > 2 && $hit >= count( $words ) - 1 ) ) {
			$scores[ $id ] = $total;
		}
	}
	arsort( $scores );
	return array_map( 'intval', array_keys( $scores ) );
}

/**
 * Use the smart results for shop searches.
 *
 * @param WP_Query $q Query.
 */
function ayat_ss_query( $q ) {
	if ( is_admin() || ! $q->is_main_query() || ! $q->is_search() ) {
		return;
	}
	$type = $q->get( 'post_type' );
	if ( 'product' !== $type && ! ( is_array( $type ) && in_array( 'product', $type, true ) ) ) {
		return;
	}
	$term = trim( (string) $q->get( 's' ) );
	if ( '' === $term ) {
		return;
	}
	$ids = ayat_ss_results( $term );
	if ( ! $ids ) {
		return; // Fall back to the normal search.
	}
	$q->set( 'ayat_ss_term', $term );
	$q->set( 's', '' );
	$q->set( 'post__in', $ids );
	$q->set( 'orderby', 'post__in' );
	$q->set( 'order', 'ASC' );
}
add_action( 'pre_get_posts', 'ayat_ss_query', 20 );

/**
 * Keep the search words on the results page (title, search box).
 *
 * @param string $s Search query.
 * @return string
 */
function ayat_ss_keep_term( $s ) {
	global $wp_query;
	if ( $wp_query && $wp_query->get( 'ayat_ss_term' ) ) {
		return (string) $wp_query->get( 'ayat_ss_term' );
	}
	return $s;
}
add_filter( 'get_search_query', 'ayat_ss_keep_term' );
