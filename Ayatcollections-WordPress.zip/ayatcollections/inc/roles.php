<?php
/**
 * "SHAYA Product Manager" role: everything a shop manager does with products,
 * stock, coupons and orders – but no access to the homepage design
 * (Customizer, banners, Shop the Look), the category pictures, store settings,
 * pages or users. Give it to staff under Users → Edit → Role.
 *
 * @package Ayatcollections
 */

defined( 'ABSPATH' ) || exit;

/**
 * Create (or refresh) the role from the WooCommerce shop manager role.
 */
function ayat_pm_role() {
	if ( '2' === get_option( 'ayat_pm_role_v' ) ) {
		return;
	}
	$shop_manager = get_role( 'shop_manager' );
	if ( ! $shop_manager ) {
		return;
	}
	$caps    = $shop_manager->capabilities;
	$blocked = array(
		// Homepage design, menus, widgets, theme.
		'edit_theme_options', 'customize', 'switch_themes', 'edit_themes',
		// Category pictures and names (products can still be put into categories).
		'manage_product_terms', 'edit_product_terms', 'delete_product_terms',
		// WooCommerce settings (payments, shipping, Easypaisa number…).
		'manage_woocommerce',
		// Pages (policy pages, home page).
		'edit_pages', 'edit_others_pages', 'edit_published_pages', 'edit_private_pages', 'publish_pages',
		'delete_pages', 'delete_others_pages', 'delete_published_pages', 'delete_private_pages',
		// Users, tools, raw HTML.
		'list_users', 'edit_users', 'create_users', 'delete_users', 'promote_users',
		'import', 'export', 'manage_categories', 'manage_links', 'unfiltered_html',
	);
	foreach ( $blocked as $cap ) {
		unset( $caps[ $cap ] );
	}
	$caps['assign_product_terms']        = true;
	$caps['upload_files']                = true;
	$caps['view_woocommerce_reports']    = true;
	remove_role( 'shaya_product_manager' );
	add_role( 'shaya_product_manager', __( 'SHAYA Product Manager', 'ayatcollections' ), $caps );
	update_option( 'ayat_pm_role_v', '2' );
}
add_action( 'init', 'ayat_pm_role', 20 );

/**
 * Keep the role off the Customizer and category screens even if a plugin
 * hands the capability back.
 *
 * @param string[] $caps    Primitive caps required.
 * @param string   $cap     Meta cap being checked.
 * @param int      $user_id User being checked.
 * @return string[]
 */
function ayat_pm_map_caps( $caps, $cap, $user_id ) {
	if ( $user_id && in_array( $cap, array( 'customize', 'edit_theme_options', 'manage_product_terms', 'edit_product_terms', 'delete_product_terms' ), true ) ) {
		$user = get_userdata( $user_id );
		if ( $user && in_array( 'shaya_product_manager', (array) $user->roles, true ) ) {
			return array( 'do_not_allow' );
		}
	}
	return $caps;
}
add_filter( 'map_meta_cap', 'ayat_pm_map_caps', 10, 3 );
