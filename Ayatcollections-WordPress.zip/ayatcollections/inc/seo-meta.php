<?php
/**
 * Search basics without a plugin: meta descriptions, canonicals, social
 * (Open Graph) tags, store schema on the home page, clearer category titles,
 * and keeping thin/private URLs (author pages, cart, checkout, account) out of
 * Google. Switches itself off when an SEO plugin (Yoast, Rank Math, AIOSEO,
 * SEOPress) is active so nothing is printed twice.
 *
 * Everything is generated from the product/category data the shop already
 * enters, so new products get it automatically.
 *
 * @package Ayatcollections
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is a dedicated SEO plugin handling this?
 *
 * @return bool
 */
function ayat_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

/**
 * Clean text to a ~155 character summary.
 *
 * @param string $text Text or HTML.
 * @param int    $max  Max length.
 * @return string
 */
function ayat_seo_trim( $text, $max = 158 ) {
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( preg_replace( '/<[^>]+>/', ' $0 ', strip_shortcodes( (string) $text ) ) ) ) );
	if ( mb_strlen( $text ) <= $max ) {
		return $text;
	}
	$cut = mb_substr( $text, 0, $max - 1 );
	$sp  = mb_strrpos( $cut, ' ' );
	return rtrim( $sp ? mb_substr( $cut, 0, $sp ) : $cut, ' ,.;:–-' ) . '…';
}

/**
 * Brand name.
 *
 * @return string
 */
function ayat_seo_brand() {
	$name = get_bloginfo( 'name' );
	return $name ? $name : 'SHAYA by AAYAT Collections';
}

/**
 * Data for the current page: description, canonical, image, type.
 *
 * @return array
 */
function ayat_seo_context() {
	static $ctx = null;
	if ( null !== $ctx ) {
		return $ctx;
	}
	$brand = ayat_seo_brand();
	$cod   = __( 'Cash on delivery all over Pakistan.', 'ayatcollections' );
	$ctx   = array(
		'desc'  => '',
		'url'   => '',
		'image' => 0,
		'type'  => 'website',
		'title' => wp_get_document_title(),
	);
	$paged = max( 1, (int) get_query_var( 'paged' ) );

	if ( is_front_page() ) {
		$ctx['desc'] = sprintf(
			/* translators: %s: brand */
			__( '%s – elegant artificial and stainless steel jewellery for women: earrings, rings, necklaces, bracelets and hand cuffs. Cash on delivery all over Pakistan.', 'ayatcollections' ),
			$brand
		);
		$ctx['url'] = home_url( '/' );
	} elseif ( function_exists( 'is_product' ) && is_product() ) {
		$product = wc_get_product( get_queried_object_id() );
		if ( $product ) {
			$cats  = wc_get_product_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
			$about = $product->get_short_description() ? $product->get_short_description() : $product->get_description();
			$price = $product->get_price() ? html_entity_decode( wp_strip_all_tags( wc_price( wc_get_price_to_display( $product ) ) ), ENT_QUOTES, 'UTF-8' ) : '';
			$lead  = $product->get_name() . ( $cats ? ' – ' . $cats[0] : '' ) . ( $price ? ', ' . $price : '' ) . '.';
			$about = ayat_seo_trim( $about, 90 );
			$ctx['desc']  = ayat_seo_trim( $lead . ' ' . ( $about ? rtrim( $about, '.' ) . '. ' : '' ) . $cod );
			$ctx['url']   = get_permalink( $product->get_id() );
			$ctx['image'] = (int) $product->get_image_id();
			$ctx['type']  = 'product';
		}
	} elseif ( function_exists( 'is_product_category' ) && ( is_product_category() || is_product_tag() ) ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			$ctx['desc'] = ayat_seo_trim(
				( $term->description ? rtrim( wp_strip_all_tags( $term->description ), '. ' ) . '. ' : '' ) .
					sprintf(
						/* translators: 1: category, 2: brand, 3: cash on delivery line */
						__( 'Shop %1$s for women at %2$s – elegant artificial jewellery designs, ready to gift. %3$s', 'ayatcollections' ),
						strtolower( $term->name ),
						$brand,
						$cod
					)
			);
			$ctx['url']   = get_term_link( $term );
			$ctx['image'] = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
		}
	} elseif ( function_exists( 'is_shop' ) && is_shop() ) {
		$ctx['desc'] = ayat_seo_trim( sprintf( __( 'Shop all artificial jewellery at %1$s – earrings, rings, necklaces, bracelets, anklets and more. %2$s', 'ayatcollections' ), $brand, $cod ) );
		$ctx['url']  = wc_get_page_permalink( 'shop' );
	} elseif ( is_singular() ) {
		$post        = get_queried_object();
		$ctx['desc'] = ayat_seo_trim( has_excerpt( $post ) ? $post->post_excerpt : $post->post_content );
		$ctx['url']  = get_permalink( $post );
		$ctx['image'] = (int) get_post_thumbnail_id( $post );
		$ctx['type']  = is_page() ? 'website' : 'article';
	}

	if ( $ctx['url'] && ! is_wp_error( $ctx['url'] ) && $paged > 1 && ! is_singular() ) {
		$ctx['url'] = trailingslashit( $ctx['url'] ) . 'page/' . $paged . '/';
	}
	if ( is_wp_error( $ctx['url'] ) ) {
		$ctx['url'] = '';
	}
	return $ctx;
}

/**
 * Print description, canonical (where WordPress does not) and social tags.
 */
function ayat_seo_head() {
	if ( ayat_seo_plugin_active() || is_404() || is_search() ) {
		return;
	}
	$c = ayat_seo_context();
	if ( $c['desc'] ) {
		echo '<meta name="description" content="' . esc_attr( $c['desc'] ) . '">' . "\n";
	}
	// WordPress prints a canonical for single posts/pages/products; add it for the rest.
	if ( $c['url'] && ( ! is_singular() || is_front_page() ) && ! ( is_front_page() && is_singular() ) ) {
		echo '<link rel="canonical" href="' . esc_url( $c['url'] ) . '">' . "\n";
	}
	$img = $c['image'] ? wp_get_attachment_image_url( $c['image'], 'large' ) : '';
	if ( ! $img ) {
		$logo = get_theme_mod( 'custom_logo' );
		$img  = $logo ? wp_get_attachment_image_url( $logo, 'full' ) : AYAT_URI . '/assets/images/logo-shaya.webp';
	}
	$tags = array(
		'og:site_name'   => ayat_seo_brand(),
		'og:locale'      => 'en_PK',
		'og:type'        => $c['type'],
		'og:title'       => $c['title'],
		'og:description' => $c['desc'],
		'og:url'         => $c['url'],
		'og:image'       => $img,
	);
	foreach ( $tags as $k => $v ) {
		if ( $v ) {
			echo '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
		}
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	if ( 'product' === $c['type'] ) {
		$product = wc_get_product( get_queried_object_id() );
		if ( $product && '' !== $product->get_price() ) {
			echo '<meta property="product:price:amount" content="' . esc_attr( wc_get_price_to_display( $product ) ) . '">' . "\n";
			echo '<meta property="product:price:currency" content="' . esc_attr( get_woocommerce_currency() ) . '">' . "\n";
		}
	}
}
add_action( 'wp_head', 'ayat_seo_head', 2 );

/**
 * Store schema (who we are + site search) on the home page.
 */
function ayat_seo_home_schema() {
	if ( ayat_seo_plugin_active() || ! is_front_page() ) {
		return;
	}
	$home  = home_url( '/' );
	$logo  = get_theme_mod( 'custom_logo' );
	$logo  = $logo ? wp_get_attachment_image_url( $logo, 'full' ) : AYAT_URI . '/assets/images/logo-shaya.webp';
	$same  = array();
	$socials = function_exists( 'ayat_social_links' ) ? (array) ayat_social_links() : array();
	foreach ( $socials as $label => $url ) {
		if ( is_string( $url ) && 0 === strpos( $url, 'http' ) && false === strpos( $url, 'wa.me' ) ) {
			$same[] = $url;
		}
	}
	$store = array(
		'@type'       => 'OnlineStore',
		'@id'         => $home . '#store',
		'name'        => ayat_seo_brand(),
		'url'         => $home,
		'logo'        => $logo,
		'image'       => $logo,
		'description' => ayat_seo_context()['desc'],
		'areaServed'  => array( '@type' => 'Country', 'name' => 'Pakistan' ),
		'currenciesAccepted' => 'PKR',
		'paymentAccepted'    => 'Cash on Delivery, Easypaisa',
	);
	if ( $same ) {
		$store['sameAs'] = array_values( array_unique( $same ) );
	}
	$site = array(
		'@type'     => 'WebSite',
		'@id'       => $home . '#website',
		'url'       => $home,
		'name'      => ayat_seo_brand(),
		'publisher' => array( '@id' => $home . '#store' ),
		'inLanguage' => 'en-PK',
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => array( '@type' => 'EntryPoint', 'urlTemplate' => add_query_arg( array( 's' => '{search_term_string}', 'post_type' => 'product' ), $home ) ),
			'query-input' => 'required name=search_term_string',
		),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => array( $store, $site ) ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'ayat_seo_home_schema', 20 );

/**
 * Clearer titles for category pages, e.g. "Rings for Women – Artificial Jewellery in Pakistan".
 *
 * @param array $parts Title parts.
 * @return array
 */
function ayat_seo_title_parts( $parts ) {
	if ( ayat_seo_plugin_active() ) {
		return $parts;
	}
	if ( function_exists( 'is_product_category' ) && is_product_category() ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			/* translators: %s: category */
			$parts['title'] = sprintf( __( '%s for Women – Artificial Jewellery in Pakistan', 'ayatcollections' ), $term->name );
		}
	}
	return $parts;
}
add_filter( 'document_title_parts', 'ayat_seo_title_parts' );

/**
 * Keep thin or private pages out of Google: author archives, internal search,
 * cart / checkout / my account.
 *
 * @param array $robots Robots directives.
 * @return array
 */
function ayat_seo_robots( $robots ) {
	$private = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() );
	if ( is_author() || is_search() || $private ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
		unset( $robots['max-image-preview'] );
	}
	return $robots;
}
add_filter( 'wp_robots', 'ayat_seo_robots', 20 );

/**
 * Author pages are not useful for a shop (and show staff names): send them home.
 */
function ayat_seo_author_redirect() {
	if ( is_author() && ! is_admin() ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'ayat_seo_author_redirect' );

/**
 * Sitemap: drop the users list, and cart / checkout / account pages.
 */
add_filter(
	'wp_sitemaps_add_provider',
	static function ( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	},
	10,
	2
);
add_filter(
	'wp_sitemaps_posts_query_args',
	static function ( $args, $post_type ) {
		if ( 'page' === $post_type && function_exists( 'wc_get_page_id' ) ) {
			$skip = array_filter( array( wc_get_page_id( 'cart' ), wc_get_page_id( 'checkout' ), wc_get_page_id( 'myaccount' ) ), static fn( $id ) => $id > 0 );
			$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), $skip );
		}
		return $args;
	},
	10,
	2
);


/**
 * Richer product data for Google (brand, condition, delivery cost and time in
 * Pakistan) - helps products qualify for free Google Shopping listings.
 *
 * @param array      $markup  Product structured data.
 * @param WC_Product $product Product.
 * @return array
 */
function ayat_seo_product_schema( $markup, $product ) {
	$markup['brand'] = array(
		'@type' => 'Brand',
		'name'  => 'SHAYA',
	);
	if ( empty( $markup['sku'] ) ) {
		$markup['sku'] = 'SHAYA-' . $product->get_id();
	}
	$cats = wc_get_product_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
	if ( $cats ) {
		$markup['category'] = $cats[0];
	}
	if ( ! empty( $markup['offers'] ) && is_array( $markup['offers'] ) ) {
		$cost = (string) apply_filters( 'ayat_seo_delivery_cost', '250' );
		foreach ( $markup['offers'] as $i => $offer ) {
			if ( ! is_array( $offer ) ) {
				continue;
			}
			$markup['offers'][ $i ]['itemCondition']   = 'https://schema.org/NewCondition';
			$markup['offers'][ $i ]['shippingDetails'] = array(
				'@type'               => 'OfferShippingDetails',
				'shippingRate'        => array(
					'@type'    => 'MonetaryAmount',
					'value'    => $cost,
					'currency' => 'PKR',
				),
				'shippingDestination' => array(
					'@type'          => 'DefinedRegion',
					'addressCountry' => 'PK',
				),
				'deliveryTime'        => array(
					'@type'        => 'ShippingDeliveryTime',
					'handlingTime' => array( '@type' => 'QuantitativeValue', 'minValue' => 0, 'maxValue' => 2, 'unitCode' => 'DAY' ),
					'transitTime'  => array( '@type' => 'QuantitativeValue', 'minValue' => 3, 'maxValue' => 5, 'unitCode' => 'DAY' ),
				),
			);
		}
	}
	return $markup;
}
add_filter( 'woocommerce_structured_data_product', 'ayat_seo_product_schema', 20, 2 );

/**
 * Common questions (home page + FAQ data for Google / AI answers).
 *
 * @return array[]
 */
function ayat_seo_faqs() {
	return apply_filters(
		'ayat_seo_faqs',
		array(
			array( __( 'Do you offer Cash on Delivery?', 'ayatcollections' ), __( 'Yes. You can pay in cash when your order arrives, anywhere in Pakistan. You can also pay in advance by Easypaisa.', 'ayatcollections' ) ),
			array( __( 'How long does delivery take and what does it cost?', 'ayatcollections' ), __( 'Orders are usually delivered in 3 to 5 working days across Pakistan. A flat delivery charge of Rs 250 is added at checkout.', 'ayatcollections' ) ),
			array( __( 'What is SHAYA jewellery made of?', 'ayatcollections' ), __( 'Our pieces are gold-tone stainless steel artificial jewellery with an anti-tarnish, water-resistant finish, made for everyday wear.', 'ayatcollections' ) ),
			array( __( 'How do I choose my ring size?', 'ayatcollections' ), __( 'Each ring page shows the sizes available. Pick your size before adding to bag, or message us on WhatsApp and we will help you choose.', 'ayatcollections' ) ),
			array( __( 'Do you accept exchanges?', 'ayatcollections' ), __( 'We do not offer exchanges, so please check size and colour before ordering. If an item arrives damaged or wrong, tell us on WhatsApp within 48 hours with photos and we will make it right.', 'ayatcollections' ) ),
			array( __( 'Is it gift-ready?', 'ayatcollections' ), __( 'Yes. Every order is packed in a SHAYA gift box, ready to give.', 'ayatcollections' ) ),
		)
	);
}

/**
 * FAQ schema on the home page.
 */
function ayat_seo_faq_schema() {
	if ( ayat_seo_plugin_active() || ! is_front_page() ) {
		return;
	}
	$items = array();
	foreach ( ayat_seo_faqs() as $f ) {
		$items[] = array(
			'@type'          => 'Question',
			'name'           => $f[0],
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f[1] ),
		);
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'ayat_seo_faq_schema', 21 );
