<?php
/**
 * Colour swatches.
 *
 * For a variable product with a "Color" / "Colour" / "Rang" attribute:
 * - product cards show small round swatches (the photo of each colour);
 *   tapping one swaps the card photo and links to that colour;
 * - the product page shows the same swatches instead of the colour dropdown,
 *   and choosing one switches the main photo and price.
 *
 * Nothing to set up: give each variation its own photo in
 * Product data → Variations.
 *
 * @package Ayatcollections
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is this attribute a colour attribute?
 *
 * @param string $attribute Attribute name (pa_color or Color).
 * @return bool
 */
function ayat_sw_is_colour( $attribute ) {
	$label = taxonomy_exists( $attribute ) ? wc_attribute_label( $attribute ) : $attribute;
	return (bool) preg_match( '/colou?r|rang|shade/i', $attribute . ' ' . $label );
}

/**
 * CSS colour for a colour name, when there is no photo.
 *
 * @param string $name Colour name.
 * @return string
 */
function ayat_sw_css_colour( $name ) {
	$map = array(
		'gold'      => 'linear-gradient(135deg,#f6dd9a,#c79244)',
		'golden'    => 'linear-gradient(135deg,#f6dd9a,#c79244)',
		'silver'    => 'linear-gradient(135deg,#f4f4f4,#a9a9a9)',
		'rose gold' => 'linear-gradient(135deg,#f7d0c4,#c98b7a)',
		'rosegold'  => 'linear-gradient(135deg,#f7d0c4,#c98b7a)',
		'black'     => '#1d1d1d',
		'white'     => '#ffffff',
		'pearl'     => 'linear-gradient(135deg,#fffdf6,#e9e1cf)',
		'red'       => '#b3202c',
		'maroon'    => '#7b1e2b',
		'pink'      => '#f2a7bb',
		'green'     => '#1f7a4d',
		'emerald'   => '#0f7a52',
		'blue'      => '#2a55a5',
		'navy'      => '#1d2b55',
		'purple'    => '#6c3b8f',
		'brown'     => '#7a5230',
		'multi'     => 'conic-gradient(#e94b4b,#f2c94c,#3fbf7f,#3f7fbf,#a35bd6,#e94b4b)',
	);
	$key = strtolower( trim( $name ) );
	return $map[ $key ] ?? '#e8dcc6';
}

/**
 * One swatch per colour: label, slug, photo.
 *
 * @param WC_Product_Variable $product Product.
 * @param string              $attribute Attribute name.
 * @return array[]
 */
function ayat_sw_colours( $product, $attribute ) {
	$key  = 'attribute_' . sanitize_title( $attribute );
	$out  = array();
	foreach ( $product->get_available_variations( 'objects' ) as $variation ) {
		$attrs = $variation->get_attributes();
		$value = $attrs[ sanitize_title( $attribute ) ] ?? '';
		if ( '' === $value || isset( $out[ $value ] ) ) {
			continue;
		}
		$label = $value;
		if ( taxonomy_exists( $attribute ) ) {
			$term  = get_term_by( 'slug', $value, $attribute );
			$label = $term ? $term->name : $value;
		}
		$out[ $value ] = array(
			'slug'  => $value,
			'label' => $label,
			'key'   => $key,
			'image' => (int) $variation->get_image_id(),
		);
	}
	return array_values( $out );
}

/**
 * Colour attribute of a product, or ''.
 *
 * @param WC_Product $product Product.
 * @return string
 */
function ayat_sw_attribute( $product ) {
	if ( ! $product || ! $product->is_type( 'variable' ) ) {
		return '';
	}
	foreach ( array_keys( $product->get_variation_attributes() ) as $attribute ) {
		if ( ayat_sw_is_colour( $attribute ) ) {
			return $attribute;
		}
	}
	return '';
}

/**
 * Swatch markup inside a button.
 *
 * @param array $c Colour.
 * @return string
 */
function ayat_sw_dot( $c ) {
	if ( $c['image'] ) {
		return wp_get_attachment_image( $c['image'], 'thumbnail', false, array( 'alt' => '', 'loading' => 'lazy', 'class' => 'ayat-sw__img' ) );
	}
	return '<span class="ayat-sw__dot" style="background:' . esc_attr( ayat_sw_css_colour( $c['label'] ) ) . '"></span>';
}

/**
 * Swatch on the product page: the real colour when the name is a known
 * colour (gold, silver, rose gold…), otherwise the variation photo.
 *
 * @param array $c Colour.
 * @return string
 */
function ayat_sw_single_dot( $c ) {
	$css = ayat_sw_css_colour( $c['label'] );
	if ( '#e8dcc6' !== $css || ! $c['image'] ) {
		return '<span class="ayat-sw__dot" style="background:' . esc_attr( $css ) . '"></span>';
	}
	return wp_get_attachment_image( $c['image'], 'thumbnail', false, array( 'alt' => '', 'loading' => 'lazy', 'class' => 'ayat-sw__img' ) );
}

/**
 * Swatches on product cards.
 */
function ayat_sw_loop() {
	global $product;
	$attribute = ayat_sw_attribute( $product );
	if ( ! $attribute ) {
		return;
	}
	$colours = ayat_sw_colours( $product, $attribute );
	if ( count( $colours ) < 2 ) {
		return;
	}
	$link = get_permalink( $product->get_id() );
	$max  = 5;
	echo '<div class="ayat-sw ayat-sw--card" role="group" aria-label="' . esc_attr__( 'Colours', 'ayatcollections' ) . '">';
	foreach ( array_slice( $colours, 0, $max ) as $c ) {
		$src    = $c['image'] ? wp_get_attachment_image_url( $c['image'], 'woocommerce_thumbnail' ) : '';
		$srcset = $c['image'] ? wp_get_attachment_image_srcset( $c['image'], 'woocommerce_thumbnail' ) : '';
		printf(
			'<button type="button" class="ayat-sw__b" data-src="%1$s" data-srcset="%2$s" data-href="%3$s" title="%4$s" aria-label="%4$s">%5$s</button>',
			esc_url( (string) $src ),
			esc_attr( (string) $srcset ),
			esc_url( add_query_arg( $c['key'], $c['slug'], $link ) ),
			esc_attr( $c['label'] ),
			ayat_sw_single_dot( $c ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}
	if ( count( $colours ) > $max ) {
		echo '<a class="ayat-sw__more" href="' . esc_url( $link ) . '">+' . esc_html( count( $colours ) - $max ) . '</a>';
	}
	echo '</div>';
}
add_action( 'woocommerce_after_shop_loop_item', 'ayat_sw_loop', 7 );

/**
 * Swatches instead of the colour dropdown on the product page.
 *
 * @param string $html Dropdown HTML.
 * @param array  $args Arguments.
 * @return string
 */
function ayat_sw_single( $html, $args ) {
	$product   = $args['product'] ?? null;
	$attribute = $args['attribute'] ?? '';
	if ( ! $product || ! ayat_sw_is_colour( $attribute ) ) {
		return $html;
	}
	$colours = ayat_sw_colours( $product, $attribute );
	if ( ! $colours ) {
		return $html;
	}
	$out = '<div class="ayat-sw ayat-sw--single" role="radiogroup" aria-label="' . esc_attr( wc_attribute_label( $attribute, $product ) ) . '" data-for="' . esc_attr( ! empty( $args['id'] ) ? $args['id'] : sanitize_title( $attribute ) ) . '">';
	foreach ( $colours as $c ) {
		$out .= '<button type="button" class="ayat-sw__b" role="radio" aria-checked="false" data-value="' . esc_attr( $c['slug'] ) . '" data-label="' . esc_attr( $c['label'] ) . '" title="' . esc_attr( $c['label'] ) . '"><span class="ayat-sw__swatch">' . ayat_sw_single_dot( $c ) . '</span><span class="ayat-sw__label">' . esc_html( $c['label'] ) . '</span></button>';
	}
	$out .= '</div>';
	return '<div class="ayat-sw-select">' . $html . '</div>' . $out;
}
add_filter( 'woocommerce_dropdown_variation_attribute_options_html', 'ayat_sw_single', 20, 2 );
